# 취약한 뱅킹 시스템 ERD

교육용 보안 취약점 학습 시스템 데이터베이스 설계

## Mermaid 다이어그램

```mermaid
erDiagram
    USER ||--o{ ACCOUNT : "owns"
    USER ||--o{ QNA : "writes"
    USER ||--o{ FILE_UPLOAD : "uploads"
    ACCOUNT ||--o{ TRANSACTION : "has"
    ACCOUNT ||--o{ TRANSACTION : "receives"
    QNA ||--o{ FILE_UPLOAD : "attaches"
    
    USER {
        int user_id PK
        string username UK
        string password
        string email UK
        string name
        string phone
        datetime created_at
        datetime updated_at
        boolean is_active
        string session_token
    }
    
    ACCOUNT {
        int account_id PK
        int user_id FK
        string account_number UK
        string account_type
        decimal balance
        string currency
        datetime created_at
        datetime updated_at
        boolean is_active
    }
    
    TRANSACTION {
        int transaction_id PK
        int from_account_id FK
        int to_account_id FK
        string transaction_type
        decimal amount
        decimal balance_after
        string memo
        string status
        datetime created_at
        string ip_address
    }
    
    NOTICE {
        int notice_id PK
        string title
        text content
        int view_count
        boolean is_pinned
        datetime created_at
        datetime updated_at
    }
    
    QNA {
        int qna_id PK
        int user_id FK
        string title
        text content
        string status
        text admin_reply
        datetime created_at
        datetime updated_at
        datetime replied_at
    }
    
    FILE_UPLOAD {
        int file_id PK
        int user_id FK
        int qna_id FK
        string original_filename
        string stored_filename
        string file_path
        string file_type
        int file_size
        string upload_type
        datetime uploaded_at
    }
    
    SESSION {
        int session_id PK
        int user_id FK
        string session_token UK
        datetime created_at
        datetime expires_at
        string ip_address
        string user_agent
    }
```

## 주요 엔티티 설명

- **USER**: 사용자 정보 (SQLi 취약점 대상)
- **ACCOUNT**: 계좌 정보 (IDOR 취약점 대상)
- **TRANSACTION**: 거래내역 (SQLi, IDOR, CSRF 취약점 대상)
- **NOTICE**: 공지사항 (XSS 취약점 대상)
- **QNA**: 1:1 문의 (XSS, File Upload 취약점 대상)
- **FILE_UPLOAD**: 첨부파일 (File Upload, Path Traversal 취약점 대상)
- **SESSION**: 세션 관리 (세션 관리 취약점 대상)

## 온라인 Mermaid 뷰어

위 코드를 다음 사이트에서 붙여넣어 확인할 수 있습니다:
- https://mermaid.live
- https://mermaid-js.github.io/mermaid-live-editor
